/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package latihan1;

/**
 *
 * @author Fatah
 */
import java.sql.*;
import java.sql.Connection;
import java.sql.Statement;
import javax.swing.JOptionPane;
public class Koneksi{
    static final String Driver= "com.mysql.jdbc.Driver";
    static final String url= "jdbc:mysql://localhost/penjualan_barang";
    static final String user= "root";
    static final String upass= "";
    static Connection conn;
    static Statement stm; 
        public static void konek() {
            try{
                Class.forName(Driver);
                conn=DriverManager.getConnection(url, user, upass);
                stm=conn.createStatement();
                System.out.println("Koneksi Berhasil");
               }catch(Exception e){
            JOptionPane.showMessageDialog(null, "koneksi gagal "+e.getMessage());
            }
        }
    }

    



     

